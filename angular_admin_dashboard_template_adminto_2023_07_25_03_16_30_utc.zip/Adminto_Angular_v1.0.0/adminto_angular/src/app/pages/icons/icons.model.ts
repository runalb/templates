export interface Icon {
    name: string;
    variant?: string;
    category?: string;
}