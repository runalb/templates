export type Variant =
    | 'primary'
    | 'secondary'
    | 'success'
    | 'danger'
    | 'warning'
    | 'info'
    | 'pink'
    | 'purple'
    | 'light'
    | 'dark';