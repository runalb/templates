export interface MapConfig {
    lat: number;
    lng: number;
    title?: string;
    markers?: MapConfig[];
    styles?: any[];
}
