export interface SearchResultItem {
    id?: number;
    text?: string;
    icon?: string;
}

export interface SearchUserItem {
    id?: number;
    name?: string;
    position?: string;
    profile?: string;
}