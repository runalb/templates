export interface ExternalEvent {
    id?: number;
    title?: string;
    type?: string;
}