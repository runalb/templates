import { Member } from "src/app/shared/widget/member-card/member.model";

const CONTACTS: Member[] = [
    {
        id: 1,
        avatar: 'assets/images/users/user-10.jpg',
        bio: 'Hi I am Johnathn Deo, has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type.',
        name: 'Johnathan Deo',
        mobile: '(123) 123 1234',
        email: 'coderthemes@gmail.com',
        location: 'USA',
    },
    {
        id: 2,
        avatar: 'assets/images/users/user-9.jpg',
        bio: 'Hi I am Johnathn Deo, has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type.',
        name: 'Johnathan Deo',
        mobile: '(123) 123 1234',
        email: 'coderthemes@gmail.com',
        location: 'USA',
    },
    {
        id: 3,
        avatar: 'assets/images/users/user-8.jpg',
        bio: 'Hi I am Johnathn Deo, has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type.',
        name: 'Johnathan Deo',
        mobile: '(123) 123 1234',
        email: 'coderthemes@gmail.com',
        location: 'USA',
    },
    {
        id: 4,
        avatar: 'assets/images/users/user-7.jpg',
        bio: 'Hi I am Johnathn Deo, has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type.',
        name: 'Johnathan Deo',
        mobile: '(123) 123 1234',
        email: 'coderthemes@gmail.com',
        location: 'USA',
    },
    {
        id: 5,
        avatar: 'assets/images/users/user-6.jpg',
        bio: 'Hi I am Johnathn Deo, has been the industrys standard dummy text ever since the5500s, when an unknown printer took a galley of type.',
        name: 'Johnathan Deo',
        mobile: '(123) 123 1234',
        email: 'coderthemes@gmail.com',
        location: 'USA',
    },
    {
        id: 6,
        avatar: 'assets/images/users/user-5.jpg',
        bio: 'Hi I am Johnathn Deo, has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type.',
        name: 'Johnathan Deo',
        mobile: '(123) 123 1234',
        email: 'coderthemes@gmail.com',
        location: 'USA',
    },
];

export { CONTACTS };
