import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-profile-post-box',
  templateUrl: './post-box.component.html',
  styleUrls: ['./post-box.component.scss']
})
export class PostBoxComponent implements OnInit {

  constructor () { }

  ngOnInit(): void {
  }

}
