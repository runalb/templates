import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-profile-user-box',
  templateUrl: './user-box.component.html',
  styleUrls: ['./user-box.component.scss']
})
export class UserBoxComponent implements OnInit {

  constructor () { }

  ngOnInit(): void {
  }

}
